﻿using System.Reflection;

// General Information about an assembly.
[assembly: AssemblyCompany("RJRamirez")]
[assembly: AssemblyProduct("BoosterTest")]
[assembly: AssemblyCopyright("Copyright © RJRamirez 2023")]
[assembly: AssemblyVersion("1.0.*")]
