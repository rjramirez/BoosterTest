﻿namespace Common.DataTransferObjects.WordStream
{
    public class WordDetail
    {
        public int Occurrences { get; set; }

        public string Word { get; set; }
    }
}
